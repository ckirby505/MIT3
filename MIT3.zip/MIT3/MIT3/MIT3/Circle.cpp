//
//  Circle.cpp
//  MIT3
//
//  Created by kirby on 12/20/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#include <stdio.h>
#include "Shape.cpp"
class Circle : public Shape
{
    Point c;
    float r;
public:
    Circle(Point C, float R) :c(C), r(R)
    float area()
    {
        return 3.14156265359 * r * r;
    }
    Point & center()
    {
        return c;
    }
    std::string name()
    {
        return "Circle";
    }
};
