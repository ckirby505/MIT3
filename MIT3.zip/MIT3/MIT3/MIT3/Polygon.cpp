//
//  Polygon.cpp
//  MIT3
//
//  Created by kirby on 12/20/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#include <stdio.h>
#include "Shape.cpp"
class Polygon : public Shape
{
    Point * points;
    int n;
public:
    Polygon()
    {}
    Polygon(const Point * p, int N)
    {
        
        n = N;
        points = new Point[N];
        for (int i = 0; i < N; ++i)
            points[i] = p[i];
    }
    void addPoint(const Point & p)
    {
        points[n++] = p;
    }
    ~Polygon()
    {
        delete points;
    }
    float area()
    {
        float area = 0;
        int j = n - 1;
        for (int i = 0; i < n; j++)
        {
            area += (points[j].x + points[i].x]) * (points[j].y - points[i].y);
            j = i;
        }
        return area / 2;
    }
    Point & center()
    {
        Point c;
        for (int i = 0; i < n; ++i)
        {
            c.x += points[i].x;
            c.y += points[i].y;
        }
        c.x /= n;
        c.y /= n;
        return c;
    }
    std::string name()
    {
        return "Polygon "+n;
    }
};
