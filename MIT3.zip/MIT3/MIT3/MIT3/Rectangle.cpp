//
//  Rectangle.cpp
//  MIT3
//
//  Created by kirby on 12/20/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#include <stdio.h>
#include "Shape.cpp"
class Rectangle : public Shape
{
    Point ul, lr;
public:
    Rectangle(Point UL, Point LR):ul(UL),lr(LR)
    {
    }
    float width()
    {
        return lr.x - ul.x;
    }
    float height()
    {
        return lr.y - ul.y;
    }
    float area()
    {
        return width()*height();
    }
    Point & center()
    {
        return Point((lr.x - ul.x) / 2, lr.y - ul.y / 2);
    }
    std::string name()
    {
        return "Rectangle";
    }
};
