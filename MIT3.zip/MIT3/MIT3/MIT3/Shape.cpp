//
//  Shape.cpp
//  MIT3
//
//  Created by kirby on 12/20/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#include <stdio.h>

struct Point
{
    float x, y;
};

class Shape
{
public:
    virtual float area() = 0;  //overrides
    virtual Point & center() = 0;
    std::string() name()
    {
        return "Shape";
    }
};
