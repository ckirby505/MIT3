//
//  main.cpp
//  MIT3
//
//  Created by kirby on 12/19/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#include <iostream>
#include "Shape.cpp"
//#include "All.cpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
